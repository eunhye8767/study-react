const NoSSR = () => {
  return <p>width: {window.innerWidth}</p>;
};
export default NoSSR;
