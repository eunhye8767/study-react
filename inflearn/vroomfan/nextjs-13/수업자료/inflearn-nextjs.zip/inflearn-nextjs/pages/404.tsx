/** https://nextjs.org/docs/advanced-features/custom-error-page#404-page */
export default function Custom404() {
  return <h1>해당 매장을 찾을 수 없습니다.</h1>;
}
