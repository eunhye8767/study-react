export interface Feedback {
  content: string;
  timestamp: number;
}
